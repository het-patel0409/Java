/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package hiddenform;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author iampo
 */
public class Hidden1 extends HttpServlet {
@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body bgcolor='red'>");
        
        out.println("<Form action='Hidden2' method='Post'>");
        
        out.println("Name:- <Input type='text' name='name'><br><br>");
        out.println("Password:- <Input type='password' name='password'><br><br>");
        out.println("<Input type='submit' value='Submit'><br><br>");
        
        out.println("</from>");
        out.println("</body>");
        out.println("</html>");
    }
    
}
