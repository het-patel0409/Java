/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * For MyFilter create java class not servlet bz its uses implements
 * This MyFilter is for MyServlet.java
 * html code is commonly written in index.html having 1 hyper link
 * @author iampo
 */
public class MyFilter implements Filter {
    
    FilterConfig config;
    
    @Override
    public void init(FilterConfig config) throws ServletException {
        this.config=config;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc)
            throws IOException, ServletException {
            PrintWriter out = response.getWriter();

		String env = config.getInitParameter("Pooja");

		if (env.equals("Core Java")) {
			out.println("KK Teaches Core Java");
		} 
                else if (env.equals("Advance Java")){
			fc.doFilter(request, response);// forward the request to next resource
		}
    }

    @Override
    public void destroy() {
       
    }

}
