/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package filter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
/**
 *
 * This code has MyFilter1.java(created .java class not servlet)
 * 
 * @author iampo
 */
public class OrderServlet extends HttpServlet {

   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        System.out.println("Order Servlet Executed.......");
        out.println("<html>");
        out.println("<body bgcolor ='teal'>");
        out.println("<h1> Welcome to Order Servlet..!!</h1>");
        out.println("<body>");
        out.println("<html>");
    }

}
