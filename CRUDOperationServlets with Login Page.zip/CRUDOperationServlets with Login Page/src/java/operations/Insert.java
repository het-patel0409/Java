/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package operations;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


/**
 *
 * @author iampo
 */
public class Insert extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body>");
        out.println("<center><h1>Insert Student <h1> <Center>");

        String sno=request.getParameter("sno");
        String sname=request.getParameter("sname");
        String age=request.getParameter("age");
        String username=request.getParameter("uname");
        String password=request.getParameter("pass");
        Connection con=null;
        try
        {
             //Loading driver 
            Class.forName("oracle.jdbc.OracleDriver");
            //Building bridge between java & database
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
            //Building query
            String query="Insert into Student values(" + sno + ",'" + sname + "'," + age + ",'" + username + "','" + password + "')";
            Statement stmt=con.createStatement();
            stmt.executeUpdate(query);
            stmt.close();
            con.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        response.sendRedirect("List");
        out.println("</body>");
        out.println("</html>");
    }

}
