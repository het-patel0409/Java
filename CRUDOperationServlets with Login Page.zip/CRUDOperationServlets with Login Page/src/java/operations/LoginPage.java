/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package operations;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author iampo
 */
public class LoginPage extends HttpServlet {

   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body bgcolor= 'cyan'>");

        out.println("<center><h1>Login Page<h1> <Center>");
      
        out.println("<form action='LoginValidation'>");

        out.println("Enter UserName:<input type='text' name='uname'><br><br>");
        out.println("Enter Password:<input type='password' name='pass'><br><br>");

        out.println("<input type='submit' value='Submit'>");

        out.println("</form>");
            
        out.println("</body>");
        out.println("</html>");
    }
}
