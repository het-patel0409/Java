/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package books;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 *
 * @author iampo
 */
public class Add extends HttpServlet {
@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body bgcolor = 'LightSkyBlue'>");
        out.println("<center><h1>Insert Books <h1> <Center>");

        Connection con=null;
        int id=0;
        
        try
        {
             //Loading driver 
            Class.forName("oracle.jdbc.OracleDriver");
            //Building bridge between java & database
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
            //Building query
            String query="select max(id) maxnum from book";
            //Firing query to database
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(query);
            while(rs.next())
            {
                id=rs.getInt("maxnum");
            }
            rs.close();
            stmt.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        id++;
        out.println("<form action = 'Insert'>");
        out.println("<table border = '1' align='center' bgcolor='yellow' >");
        out.println("<tr><td>Book Id:</td> <td>" + id + "<input type ='hidden' name = 'id' value ='"+id+"'></td> </tr>");
        out.println("<tr><td>Book Name:</td><td> <input type='text' name='bname'></td><tr>");
        out.println("<tr><td>Book Price:</td><td> <input type='number' name='bprice'></td></tr>");
        out.println("<tr><th colspan='2'><input type='submit' value='Submit'></th></tr>");
        out.println("</table>");
        out.println("</form>");
    }
}
