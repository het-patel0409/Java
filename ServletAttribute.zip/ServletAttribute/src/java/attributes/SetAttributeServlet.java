/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package attributes;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 *
 * Set and Get attribute Servlet
 * 
 * @author iampo
 */
public class SetAttributeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        //set application scoped attribute
        request.getServletContext().setAttribute("name","Application Scoped Attribute");
        //set session scoped attribute
        HttpSession session = request.getSession();
        session.setAttribute("name","Session Scoped Attribute");
        //set request scoped attribute
        request.setAttribute("name","Request Scoped Attribute");
        //send redirect to other servlet
        RequestDispatcher rd = request.getRequestDispatcher("GetAttributeServlet");
        rd.forward(request,response);
        
    }

}