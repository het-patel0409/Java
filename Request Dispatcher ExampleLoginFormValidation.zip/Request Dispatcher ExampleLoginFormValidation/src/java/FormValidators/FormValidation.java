/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package FormValidators;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author iampo
 */
public class FormValidation extends HttpServlet {

     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<html>");
        out.println("<body bgcolor='pink'>");
        String user = request.getParameter("uname");
        String pwd = request.getParameter("upwd");
        out.println(" <b>Hello " +  user);
        if (user.equals("Pooja") && pwd.equals("Pooja"))
        {
            RequestDispatcher rd = request.getRequestDispatcher("WelcomePage");
            rd.forward(request, response);
        }
        else
        {
            out.println("<b> Sorry,  Your UserName or Password is Incorrect!!!");
            RequestDispatcher  rd = request.getRequestDispatcher("PKLoginForm");
            rd.include(request, response);
            //response.sendRedirect("PKLoginForm");
        }
        out.println("</Center>");
        out.println("</body>");
        out.println("</html>");
                
    }

    
}
