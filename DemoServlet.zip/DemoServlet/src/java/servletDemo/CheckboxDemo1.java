/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servletDemo;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author iampo
 */
public class CheckboxDemo1 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Checkbox Multiple Selection</title>");
        out.println("</head>");
        out.println("<body bgcolor='red'>");
        out.println("<form action='CheckboxDemo2' method='Post'>");
        
        out.println("<label>Select Players:</label><br>");
        out.println("Choose Your Favourite Players:----<br><input type='checkbox' name='player' value='SachinTendulkar'> Sachin Tendulkar<br>");
        out.println("<input type='checkbox' name='player' value='Virendra Sehwag'> Virendra Sehwag<br>");
        out.println("<input type='checkbox' name='player' value='Mahendra Singh Dhoni'> Mahendra Singh Dhoni<br>");
        out.println("<input type='checkbox' name='player' value='Rohit Sharma'> Rohit Sharma<br>");
        out.println("<input type='checkbox' name='player' value='Ravindra Jadeja'> Ravindra Jadeja<br><br>");
        
        out.println("<input type='submit' value='Result'>");
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }

}
