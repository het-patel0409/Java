/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servletDemo;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
/**
 *
 * @author iampo
 */
public class Servlet_1 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body bgcolor='red'>");
        
        out.println("<Form action='Servlet_2' method='Post'>");
        
        out.println("First Number:- <Input type='text' name='fno'><br><br>");
        out.println("Second Number:- <Input type='text' name='sno'><br><br>");
        out.println("<Input type='submit' value='Submit'><br><br>");
        
        out.println("</From>");
        
        out.println("</html>");
        out.println("</body>");
    }

    

}
