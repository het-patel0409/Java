/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servletDemo;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
/**
 *
 * @author iampo
 */
public class Servlet_4 extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body bgcolor='cyan'>");
        
        String name =request.getParameter("name");
        String email =request.getParameter("email");
        String password =request.getParameter("password");
        
        out.println("<table border='bold'>");
        
        out.println("<tr>");
        out.println("<th>Name</th>");
        out.println("<td>");
        out.println("Your Name is:- "+name);
        out.println("</td>");
        out.println("</tr>");
        
        out.println("<tr>");
        out.println("<th>Email</th>");
        out.println("<td>");
        out.println("Your email is:- "+email);
        out.println("</td>");
        out.println("</tr>");
        
        out.println("<tr>");
        out.println("<th>Password</th>");
        out.println("<td>");
        out.println("Your password is:- "+password);
        out.println("</td>");
        out.println("</tr>");
        
        out.println("</table>");
        
        out.println("</html>");
        out.println("</body>");
}
}
