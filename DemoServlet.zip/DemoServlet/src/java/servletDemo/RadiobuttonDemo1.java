/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servletDemo;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author iampo
 */
public class RadiobuttonDemo1 extends HttpServlet {
 @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Math Operation using Radio Button</title>");
        out.println("</head>");
        out.println("<body bgcolor='cyan'>");
        out.println("<form action='RadiobuttonDemo2' method='Post'>");
        
        out.println("Number 1:<input type='number' name='num1' required><br><br>");
        out.println("Number 2:<input type='number' name='num2' required><br><br>");
        
        out.println("Operation:<br><input type='radio' name='operation' value='add' required> Add<br>");
        out.println("<input type='radio' name='operation' value='sub'> Subtraction<br>");
        out.println("<input type='radio' name='operation' value='mult'> Multiplication<br>");
        out.println("<input type='radio' name='operation' value='div'> Division<br><br>");
        
        out.println("<input type='submit' value='Result'>");
        
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }
}
