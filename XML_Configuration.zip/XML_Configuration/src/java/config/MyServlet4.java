/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package config;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

/**
 *
 * ServletContext using multiple parameter passing multiple value
 * 
 * @author iampo
 */
public class MyServlet4 extends HttpServlet {

   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body bgcolor ='cyan'>");
        ServletContext context = getServletContext();
        Enumeration<String> e = context.getInitParameterNames();
        String str = "";
        while(e.hasMoreElements()){
            str = e.nextElement();
            out.println("<br><br>Name:- " +str);
            out.println("<br>Value:- " +context.getInitParameter(str));
        }
        out.println("<body>");
        out.println("<html>");
    }
}
