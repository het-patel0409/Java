/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package demourl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author iampo
 */
public class Male extends HttpServlet {
@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String user = request.getParameter("user");
        String pwd = request.getParameter("pwd");
        
        out.println("<html>");
        out.println("<body bgcolor='yellow'><br><br>");
        
        out.println("<b>Hello " + user + "<br>");
        out.println("<b>Your Password is " + pwd + "<br>");
        out.println("<b>This is Page for Male");

        out.println("</body>");
        out.println("</html>");
    }
    
    
}
